# 數位社群互動模擬與研究工具

高中職生網路性騷擾情境問卷。前端放在 GitHub Pages，答案自動寫入 Google Sheet，並附有一個需要密碼的管理頁面可檢視與匯出資料。

```
受訪者瀏覽器 (GitHub Pages: index.html)
        │  POST (JSON)
        ▼
Google Apps Script 網頁應用程式 ──寫入──▶ Google Sheet（responses 分頁）
        ▲
        │  POST (action=list + 管理密碼)
管理者瀏覽器 (admin.html)
```

## 專案結構

```
/
├── index.html          問卷主頁（提交時自動上傳）
├── admin.html          管理頁面（表格、篩選、統計、匯出）
├── config.js           ★ 唯一需要填寫的設定：Apps Script 網址
├── input_file_0.mp4    ★ 第二幕使用的影片，需自行放進來（見下方注意事項）
├── apps-script/
│   └── Code.gs         貼到 Google Apps Script 的後端程式
└── README.md
```

---

## 一、設定 Google Sheet 與後端（約 10 分鐘）

### 1. 建立 Sheet 並貼上程式碼

1. 到 [Google Sheets](https://sheets.google.com) 建立一份新的空白試算表，名稱自訂（例如「問卷資料」）。
2. 選單 **擴充功能 → Apps Script**。
3. 把編輯器內預設的程式碼全部刪除，貼上 `apps-script/Code.gs` 的完整內容，按 💾 儲存。
4. 上方函式選單選 **`setup`**，按 **執行**。第一次會要求授權：
   選擇你的帳號 →「進階」→「前往（不安全）」→ 允許。
   （這是你自己寫的指令碼，出現「未經驗證」警告是正常的。）
5. 回到試算表，應該已自動出現 `responses` 分頁與表頭。

### 2. 設定管理密碼

1. Apps Script 左側 **⚙ 專案設定** → 捲到最下方 **指令碼屬性** → **新增指令碼屬性**。
2. 屬性：`ADMIN_TOKEN`　值：自訂一組**夠長的密碼**（建議 16 字元以上，不要用生日或常見單字）。
3. 儲存。

> 密碼只存在 Google 端，不會出現在 GitHub 的程式碼裡。沒設定 `ADMIN_TOKEN` 時，管理頁會拒絕所有登入。

### 3. 部署成網頁應用程式

1. 右上角 **部署 → 新增部署作業**。
2. 類型選 **網頁應用程式**（齒輪圖示）。
3. 設定：
   - **執行身分：我**
   - **誰可以存取：任何人**
4. 按 **部署**，複製 **網頁應用程式網址**（`https://script.google.com/macros/s/.../exec`）。

### 4. 填入前端設定

開啟 `config.js`，把網址貼進去：

```js
window.SURVEY_CONFIG = {
  APPS_SCRIPT_URL: "https://script.google.com/macros/s/xxxxxxxx/exec"
};
```

---

## 二、上架到 GitHub Pages

1. 在 GitHub 建立新 repository（例如 `survey`）。
2. 把整個專案資料夾的檔案上傳（`index.html`、`admin.html`、`config.js`、`input_file_0.mp4`、`apps-script/`、`README.md`）。
   - 網頁操作：**Add file → Upload files**，直接拖曳。
   - 或使用 git：
     ```bash
     git init
     git add .
     git commit -m "init survey site"
     git branch -M main
     git remote add origin https://github.com/<你的帳號>/survey.git
     git push -u origin main
     ```
3. repository 的 **Settings → Pages**：
   - Source 選 **Deploy from a branch**
   - Branch 選 `main`，資料夾 `/ (root)`，按 Save。
4. 等 1–2 分鐘，網址會是：
   - 問卷：`https://<你的帳號>.github.io/survey/`
   - 管理頁：`https://<你的帳號>.github.io/survey/admin.html`

---

## 三、上線前測試（務必做）

1. 開啟問卷網址，**完整填答一次**，按下提交。
2. 確認 Google Sheet 的 `responses` 分頁出現一列資料。
3. 開啟 `admin.html`，輸入 `ADMIN_TOKEN`，確認看得到該筆資料，並測試匯出 CSV。
4. 測試完請在 Sheet 中**刪除測試列**（保留第 1 列表頭），以免混入正式資料。

---

## 四、管理頁使用說明

| 功能 | 說明 |
|---|---|
| 登入 | 輸入 `ADMIN_TOKEN`。只保存在當前分頁（sessionStorage），關閉分頁即登出 |
| 統計卡片 | 總份數、今日新增、作答時間中位數、曾遭遇比例、性別／年級／學校類型分布 |
| 篩選與搜尋 | 依性別、學校類型、年級、曾遭遇篩選；搜尋框可搜尋任何欄位 |
| 排序 | 點欄位標題切換升冪／降序 |
| 顯示欄位 | 可勾選隱藏／顯示各組欄位（基本資料、情緒、責任感、效能、旁觀者） |
| 匯出 CSV | 匯出**目前篩選結果的所有欄位**，含 UTF-8 BOM，Excel 直接開啟不會亂碼 |
| 匯出 JSON | 同上，數值欄位會轉成數字，方便匯入 Python／R |

> 也可以直接在 Google Sheet 使用 **檔案 → 下載 → CSV / Excel**，不一定要經過管理頁。

---

## 五、資料欄位說明

`responses` 分頁共 48 欄：

| 欄位 | 內容 |
|---|---|
| `timestamp` | 提交時間（台北時間） |
| `submission_id` | 隨機提交編號（用於避免網路重送造成重複資料，不含個資） |
| `duration_sec` | 從按下「同意」到提交的秒數 |
| `consent` | 固定為 `Y`（不同意者不會上傳任何資料） |
| `gender` / `school_type` / `school_other` / `grade` / `experience` | 基本資料 |
| `mood_count` | 選取的情緒格數（1–5） |
| `mood_1` ~ `mood_5` | 選取的情緒，格式 `詞彙(X:愉悅度,Y:能量)`，X、Y 皆為 1–10 |
| `mood_x_avg` / `mood_y_avg` | 所選格子的平均 X、平均 Y |
| `resp_1` ~ `resp_5` | 責任感量表（1–5 分） |
| `eff_1` ~ `eff_5` | 挺身自我效能量表（1–5 分） |
| `bystander_1` ~ `bystander_21` | 旁觀者行為傾向量表（1–5 分） |

**注意：** 資料為原始填答分數，**未做反向計分**，也未計算各量表總分／分量表分數。請依你的研究設計在分析時處理。

---

## 六、修改後端程式後要重新部署

Apps Script 的網頁應用程式是「版本制」，改了 `Code.gs` 之後，已上線的網址**不會**自動更新：

**部署 → 管理部署作業 → ✏ 編輯 → 版本選「新版本」→ 部署**

網址不會變，所以 `config.js` 不用改。

---

## 七、重要注意事項

### 影片檔
第二幕使用 `<video src="input_file_0.mp4">`，這個檔案**不在程式碼裡**，必須和 `index.html` 放在同一層，檔名要完全一致，否則該幕會是空白影片。GitHub 單檔上限 100 MB，建議壓縮到 20 MB 以內。

### 圖片來源
情境中的頭像與照片是從 Unsplash 外部連結載入，需要網路連線，且若對方移除圖片會顯示破圖。正式施測前建議下載到專案內（例如 `images/`）並改用相對路徑。

### 安全性與隱私
- **`admin.html` 的網址是公開的**，但沒有正確的 `ADMIN_TOKEN` 看不到任何資料；資料驗證是在 Google 端進行，不是靠前端隱藏。請把密碼設得夠長，並且不要在公開處分享。
- 提交端點必須設為「任何人」才能讓受訪者上傳，因此理論上任何人都能送資料進來。後端已做基本驗證（欄位、分數範圍 1–5、21 題完整、重複編號過濾），但無法完全防止惡意灌水。必要時可在 Sheet 依 `timestamp` 與 `duration_sec`（作答過短）篩除異常資料。
- 本系統**不記錄 IP、裝置資訊或任何可識別身分的資料**；Apps Script 無法取得訪客 IP。受訪者答案不會暫存在瀏覽器中。
- Google Sheet 的分享權限請只開給研究團隊，不要設成「知道連結的任何人」。
- 使用者填寫的文字（如「其他學校類型」）在寫入前會限制長度並處理 `= + - @` 開頭的內容，避免 Sheet／Excel 公式注入。
- 本研究對象為未成年學生，施測前請確認已取得**學校與研究倫理審查（IRB）所要求的同意程序**；網頁上的知情同意只是流程的一部分。

### 配額
免費 Google 帳號的 Apps Script 每日有執行次數與同時連線上限。一般班級／學校規模的施測不會遇到；若要大規模同時施測（例如整個年級同一時間填寫），建議先小規模壓力測試。

---

## 八、常見問題

**提交時顯示「上傳失敗」**
1. `config.js` 的網址是否正確、是否以 `/exec` 結尾。
2. 部署時「誰可以存取」是否選了「任何人」（不是「任何已登入 Google 帳戶的使用者」）。
3. 改過 `Code.gs` 後是否已「新增版本」重新部署。
4. 在瀏覽器直接開啟 `/exec` 網址，應該看到 `{"ok":true,"service":"survey-backend"}`。

**管理頁顯示「密碼錯誤」**
確認 `ADMIN_TOKEN` 是設在「指令碼屬性」而不是程式碼裡，且沒有多餘的空白。

**管理頁顯示「讀取失敗／server error」**
在 Apps Script 左側 **執行作業** 查看錯誤紀錄。通常是尚未執行過 `setup` 授權。

**想換 Sheet 或分頁名稱**
分頁名稱改 `Code.gs` 最上方的 `SHEET_NAME`。要換成另一份試算表，需要在新試算表中重新貼程式碼並重新部署，然後更新 `config.js` 的網址。

**想在本機測試**
直接用瀏覽器開 `index.html` 即可（`config.js` 為相對路徑），通常上傳功能也能運作；若本機測試失敗，請改用 GitHub Pages 網址測試。
